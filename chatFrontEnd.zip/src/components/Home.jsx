import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div>
      <h1>Welcome to my home page</h1>
      <p>This is a paragraph of text.</p>

      <button>
        {" "}
        <Link to="/client"> client </Link>
      </button>
      <button>
        {" "}
        <Link to="/admin"> admin </Link>
      </button>
    </div>
  );
};

export default Home;
