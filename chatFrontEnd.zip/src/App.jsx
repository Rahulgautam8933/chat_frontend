// src/App.js
import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Admin from "./components/Admin";

import Home from "./components/Home";
import Client from "./components/Client";

import { io, Socket } from "socket.io-client";

const socket = io("http://localhost:5000");

function App() {
  const [username, setUsername] = useState("");
  const [room, setRoom] = useState("");

  const joinroom = () => {
    if (username !== "" && room !== "") {
      socket.emit("join", room);
    }
  };

  return (
    <>
      <div>
        <input
          type="text"
          placeholder="room id"
          value={room}
          onChange={(e) => setRoom(e.target.value)}
        />
        <input
          type="text"
          placeholder="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <button onClick={joinroom}>join</button>
      </div>
      <Router>
        <Routes>
          <Route
            path="/admin"
            element={<Admin socket={socket} username={username} room={room} />}
          />
          <Route
            path="/client"
            element={<Client socket={socket} username={username} room={room} />}
          />
          <Route path="/" element={<Home />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
